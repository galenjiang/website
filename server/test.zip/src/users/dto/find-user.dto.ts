export class FindUserDto {
    id?: number
    username?: string
}
